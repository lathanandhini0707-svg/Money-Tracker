const CACHE='home-money-manager-v3';
const APP=['./','./index.html','./index_offline.html','./manifest.webmanifest'];
const OCR='https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js';
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(async cache=>{await cache.addAll(APP);try{await cache.add(OCR)}catch(e){}self.skipWaiting()}))});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',event=>{
 const req=event.request;
 if(req.method!=='GET') return;
 event.respondWith(caches.match(req).then(cached=>cached||fetch(req).then(res=>{const copy=res.clone();caches.open(CACHE).then(c=>c.put(req,copy)).catch(()=>{});return res}).catch(()=>caches.match('./index.html')||caches.match('./'))));
});